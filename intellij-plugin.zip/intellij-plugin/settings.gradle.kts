rootProject.name = "qonqrete-intellij"
